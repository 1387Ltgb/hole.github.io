// import { mdiHelpCircleOutline } from '@mdi/js'
// import { renderIconSvg } from '../icons.js'

// <md-icon-button href="https://google.com" target="_blank" id="help-button">
//             <md-icon>${renderIconSvg(mdiHelpCircleOutline, 'rgba(0, 0, 0, 0.25)')}</md-icon>
//           </md-icon-button>
//           <grampsjs-tooltip
//           for="help-button"
//             .appState="${this.appState}" .content="${this._('Help')}"></grampsjs-tooltip>
