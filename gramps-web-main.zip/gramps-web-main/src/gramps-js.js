import {GrampsJs} from './GrampsJs.js'
import './config.js'

customElements.define('gramps-js', GrampsJs)
